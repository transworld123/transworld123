/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "string.h"
#include "stdio.h"
#include <stdarg.h>
#include "FLASH_PAGE.h"

#define     S13              HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_10)   //sp1
#define     S14              HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_11)    //sp2
#define     S15              HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_12)    //sp3
#define     S16              HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_13)    //sp4
#define     S17              HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_14)    //sp5
#define     S18              HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_15)     //bowl storage
#define     S19              HAL_GPIO_ReadPin(GPIOD, GPIO_PIN_8)      //sp6 lemon,curd honey
#define     S20              HAL_GPIO_ReadPin(GPIOD, GPIO_PIN_10)     //
#define     S21              HAL_GPIO_ReadPin(GPIOD, GPIO_PIN_11)     //end of conveyor
#define     S22              HAL_GPIO_ReadPin(GPIOD, GPIO_PIN_12)     //juice 1
#define     S23              HAL_GPIO_ReadPin(GPIOD, GPIO_PIN_13)     //juice 2
#define     S24              HAL_GPIO_ReadPin(GPIOD, GPIO_PIN_14)     //Juice 3
#define     S25              HAL_GPIO_ReadPin(GPIOD, GPIO_PIN_15)     //juice 4
#define     S26              HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_7)      //honey
#define     S27              HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_6)       //curd
#define     S28              HAL_GPIO_ReadPin(GPIOD, GPIO_PIN_0)        //sproute 1 height sensor
#define     S29              HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_12) 		 //sproute 2 height sensor
#define     S30              HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_11) 		 //sproute 3 height sensor
#define     S31              HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_10) 		 //sproute 4 height sensor
#define     S32              HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_15) 		 //sproute 5 height sensor
#define S33 HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_11) 				 
#define     S34              HAL_GPIO_ReadPin(GPIOF, GPIO_PIN_6) 
#define S37 HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_12) 
#define     S38             HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_9)          //glass drop sensor
#define     S39             HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_10)         //customer end sensor
#define     S40             HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_9)          //glass check
#define     S41             HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_8) 
#define     S43             HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_8) 



/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
CRC_HandleTypeDef hcrc;

TIM_HandleTypeDef htim2;

UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */
//uint32_t data[]={1};
__IO uint32_t Rx_Data[2];
//char strc[2];
//uint32_t Rx_Data[4];
	 uint32_t count;
		uint8_t x=0;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_TIM2_Init(void);
static void MX_CRC_Init(void);
/* USER CODE BEGIN PFP */



void sp1();
void sp2();
void sp3();
void sp4();
void sp5();
void sp6();
void honey();
void curd();
void lemon_cut();
void juice();
void glass();
void bowlstorage();
void order();
void status();
void user_pwm_setvalue(uint16_t value);
uint8_t cmd_end[3]={0xFF,0xFF,0xFF};   //command end sequence
void nextion_string(char *ID, char *string)
{
  char buf[50];
	int len = sprintf(buf,"%s.txt=\"%s\"",ID,string);
	HAL_UART_Transmit(&huart2, (uint8_t*)buf,len,1000);
	HAL_UART_Transmit(&huart2, cmd_end,3,100);	
}
void nextion_no(char *ID, uint32_t NO)
{
  char buf1[50];
	int len = sprintf(buf1,"%s.val=%d",ID,NO);
	HAL_UART_Transmit(&huart2, (uint8_t*)buf1,len,1000);
	HAL_UART_Transmit(&huart2, cmd_end,3,100);	
}
void nextion_color(char *ID, uint32_t NO)
{
  char buf1[50];
	int len = sprintf(buf1,"%s.bco=%d",ID,NO);
	HAL_UART_Transmit(&huart2, (uint8_t*)buf1,len,1000);
	HAL_UART_Transmit(&huart2, cmd_end,3,100);	
}
uint8_t Rxdata[19];

uint8_t flag=0;
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
  HAL_UART_Receive_IT(huart,Rxdata,19);	

//	x=sizeof(Rxdata);
//	if(x!=19)
//	{ 
//	memset(Rxdata, 0, sizeof(Rxdata)); 
//	nextion_string("g0","order fail");
//	}
 if((Rxdata[0]!=0x24))   
	{
		memset(Rxdata, 0, sizeof(Rxdata));
	 	HAL_UART_GetError(&huart2);
		__HAL_UART_CLEAR_OREFLAG(&huart2);
	  // nextion_string("g0","order fail");
		//__HAL_UART_CLEAR_OREFLAG(&huart2);
	}
	 //reset RXdata 
else if((Rxdata[1]==0x45)||(Rxdata[5]==0x45)||(Rxdata[8]==0x45)||(Rxdata[12]==0x45))
{
	memset(Rxdata, 0, sizeof(Rxdata)); 
	HAL_UART_GetError(&huart2);
	__HAL_UART_CLEAR_OREFLAG(&huart2);
	//nextion_string("g0","order not received");
	//
	__NVIC_SystemReset();
}
else //nextion_sendstring("order sucessfull","");
flag=1;


}
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART2_UART_Init();
  MX_TIM2_Init();
  MX_CRC_Init();
  /* USER CODE BEGIN 2 */
	HAL_UART_Receive_IT(&huart2,Rxdata,19);
  HAL_TIM_Base_Start_IT(&htim2);
  HAL_TIM_PWM_Start(&htim2,TIM_CHANNEL_2);
	Flash_Read_Data(0x0800FFE0, Rx_Data); 
//	 HAL_Delay(100);
//	 memset(Rxdata, 0, sizeof(Rxdata)); 

//for(int x=0;x<=6;x++)
//{
//lemon_cut();
//}
//       HAL_GPIO_WritePin(GPIOF, GPIO_PIN_10,0);    //direction conveyor motor
//		   HAL_GPIO_WritePin(GPIOF, GPIO_PIN_9,0);  //brk  conveyor motor
//	     user_pwm_setvalue(300);
//			 
//			 HAL_Delay(3000);
	//order();
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
		
 //status();
    /* USER CODE END WHILE */
    /* USER CODE BEGIN 3 */
	
if(flag==1)
{
 		//HAL_GPIO_WritePin(GPIOE, GPIO_PIN_8,1); 
			HAL_Delay(1000);
		
			order();
	if(!(Rxdata[17]==0))glass();   
			flag=0;
			nextion_string("g0","Please collect your order");
			HAL_Delay(100);	
			memset(Rxdata, 0, sizeof(Rxdata)); 
			nextion_color("b0",1024); 
			nextion_no("n1",1);		 //send number to hmi
			HAL_Delay(1);	
}
//memset(Rxdata, 0, sizeof(Rxdata));
	//HAL_GPIO_WritePin(GPIOE, GPIO_PIN_8,0);
//    memset(Rxdata, 0, sizeof(Rxdata)); 
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Initializes the CPU, AHB and APB busses clocks 
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB busses clocks 
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_USART2;
  PeriphClkInit.Usart2ClockSelection = RCC_USART2CLKSOURCE_PCLK1;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief CRC Initialization Function
  * @param None
  * @retval None
  */
static void MX_CRC_Init(void)
{

  /* USER CODE BEGIN CRC_Init 0 */

  /* USER CODE END CRC_Init 0 */

  /* USER CODE BEGIN CRC_Init 1 */

  /* USER CODE END CRC_Init 1 */
  hcrc.Instance = CRC;
  hcrc.Init.DefaultPolynomialUse = DEFAULT_POLYNOMIAL_ENABLE;
  hcrc.Init.DefaultInitValueUse = DEFAULT_INIT_VALUE_ENABLE;
  hcrc.Init.InputDataInversionMode = CRC_INPUTDATA_INVERSION_NONE;
  hcrc.Init.OutputDataInversionMode = CRC_OUTPUTDATA_INVERSION_DISABLE;
  hcrc.InputDataFormat = CRC_INPUTDATA_FORMAT_BYTES;
  if (HAL_CRC_Init(&hcrc) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN CRC_Init 2 */

  /* USER CODE END CRC_Init 2 */

}

/**
  * @brief TIM2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM2_Init(void)
{

  /* USER CODE BEGIN TIM2_Init 0 */

  /* USER CODE END TIM2_Init 0 */

  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};

  /* USER CODE BEGIN TIM2_Init 1 */

  /* USER CODE END TIM2_Init 1 */
  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 1000-1;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 1000;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_PWM_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim2, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_ConfigChannel(&htim2, &sConfigOC, TIM_CHANNEL_2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM2_Init 2 */

  /* USER CODE END TIM2_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 9600;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  huart2.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart2.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOE_CLK_ENABLE();
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOF_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOE, GPIO_PIN_2|GPIO_PIN_3|GPIO_PIN_4|GPIO_PIN_5 
                          |GPIO_PIN_6|GPIO_PIN_7|GPIO_PIN_8|GPIO_PIN_9 
                          |GPIO_PIN_10|GPIO_PIN_11|GPIO_PIN_12|GPIO_PIN_13 
                          |GPIO_PIN_14|GPIO_PIN_15|GPIO_PIN_1, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13|GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_2 
                          |GPIO_PIN_3|GPIO_PIN_4|GPIO_PIN_5, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOF, GPIO_PIN_9|GPIO_PIN_10|GPIO_PIN_2|GPIO_PIN_4, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4|GPIO_PIN_5|GPIO_PIN_6|GPIO_PIN_7, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3 
                          |GPIO_PIN_4|GPIO_PIN_5|GPIO_PIN_6|GPIO_PIN_7 
                          |GPIO_PIN_8|GPIO_PIN_9, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOD, GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3|GPIO_PIN_4 
                          |GPIO_PIN_5|GPIO_PIN_6|GPIO_PIN_7, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOE, GPIO_PIN_0, GPIO_PIN_SET);

  /*Configure GPIO pins : PE2 PE3 PE6 PE7 
                           PE8 PE9 PE10 PE11 
                           PE12 PE13 PE14 PE15 */
  GPIO_InitStruct.Pin = GPIO_PIN_2|GPIO_PIN_3|GPIO_PIN_6|GPIO_PIN_7 
                          |GPIO_PIN_8|GPIO_PIN_9|GPIO_PIN_10|GPIO_PIN_11 
                          |GPIO_PIN_12|GPIO_PIN_13|GPIO_PIN_14|GPIO_PIN_15;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOE, &GPIO_InitStruct);

  /*Configure GPIO pins : PE4 PE5 PE1 */
  GPIO_InitStruct.Pin = GPIO_PIN_4|GPIO_PIN_5|GPIO_PIN_1;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOE, &GPIO_InitStruct);

  /*Configure GPIO pins : PC13 PC0 PC1 PC2 
                           PC3 PC4 PC5 */
  GPIO_InitStruct.Pin = GPIO_PIN_13|GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_2 
                          |GPIO_PIN_3|GPIO_PIN_4|GPIO_PIN_5;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : PF9 PF10 PF2 PF4 */
  GPIO_InitStruct.Pin = GPIO_PIN_9|GPIO_PIN_10|GPIO_PIN_2|GPIO_PIN_4;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOF, &GPIO_InitStruct);

  /*Configure GPIO pins : PA4 PA5 PA6 PA7 */
  GPIO_InitStruct.Pin = GPIO_PIN_4|GPIO_PIN_5|GPIO_PIN_6|GPIO_PIN_7;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : PB0 PB1 PB2 PB3 
                           PB4 PB5 PB6 PB7 
                           PB8 PB9 */
  GPIO_InitStruct.Pin = GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3 
                          |GPIO_PIN_4|GPIO_PIN_5|GPIO_PIN_6|GPIO_PIN_7 
                          |GPIO_PIN_8|GPIO_PIN_9;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pins : PB10 PB11 PB12 PB13 
                           PB14 PB15 */
  GPIO_InitStruct.Pin = GPIO_PIN_10|GPIO_PIN_11|GPIO_PIN_12|GPIO_PIN_13 
                          |GPIO_PIN_14|GPIO_PIN_15;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pins : PD8 PD9 PD10 PD11 
                           PD12 PD13 PD14 PD15 
                           PD0 */
  GPIO_InitStruct.Pin = GPIO_PIN_8|GPIO_PIN_9|GPIO_PIN_10|GPIO_PIN_11 
                          |GPIO_PIN_12|GPIO_PIN_13|GPIO_PIN_14|GPIO_PIN_15 
                          |GPIO_PIN_0;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

  /*Configure GPIO pins : PC6 PC7 PC8 PC9 
                           PC10 PC11 PC12 */
  GPIO_InitStruct.Pin = GPIO_PIN_6|GPIO_PIN_7|GPIO_PIN_8|GPIO_PIN_9 
                          |GPIO_PIN_10|GPIO_PIN_11|GPIO_PIN_12;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : PA8 PA9 PA10 PA11 
                           PA12 PA15 */
  GPIO_InitStruct.Pin = GPIO_PIN_8|GPIO_PIN_9|GPIO_PIN_10|GPIO_PIN_11 
                          |GPIO_PIN_12|GPIO_PIN_15;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pin : PF6 */
  GPIO_InitStruct.Pin = GPIO_PIN_6;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOF, &GPIO_InitStruct);

  /*Configure GPIO pins : PD1 PD2 PD3 PD4 
                           PD5 PD6 PD7 */
  GPIO_InitStruct.Pin = GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3|GPIO_PIN_4 
                          |GPIO_PIN_5|GPIO_PIN_6|GPIO_PIN_7;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

  /*Configure GPIO pin : PE0 */
  GPIO_InitStruct.Pin = GPIO_PIN_0;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_OD;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOE, &GPIO_InitStruct);

}

/* USER CODE BEGIN 4 */
void user_pwm_setvalue(uint16_t value)
{
    TIM_OC_InitTypeDef sConfigOC;
		 sConfigOC.OCMode = TIM_OCMODE_PWM1;
    sConfigOC.Pulse = value;
    sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
    sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
    HAL_TIM_PWM_ConfigChannel(&htim2, &sConfigOC, TIM_CHANNEL_2);
    HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_2);  
}
void status()
{
if(S28==0){nextion_string("t12","Empty");nextion_color("t12",63488); }
else{nextion_string("t12","Sproute1");nextion_color("t12",1024);}
if(S29==0){nextion_string("t13","Empty");nextion_color("t13",63488); }
else{nextion_string("t13","Sproute2");nextion_color("t13",1024);}
if(S30==0){nextion_string("t14","Empty");nextion_color("t14",63488); }
else{nextion_string("t14","Sproute3");nextion_color("t14",1024);}
if(S31==0){nextion_string("t15","Empty");nextion_color("t15",63488); }
else{nextion_string("t15","Sproute4");nextion_color("t15",1024);}
if(S32==0){nextion_string("t16","Empty");nextion_color("t16",63488); }
else{nextion_string("t16","Sproute4");nextion_color("t16",1024);}
if(S20==0){nextion_string("t17","Empty");nextion_color("t17",63488); }
else{nextion_string("t17","Sproute4");nextion_color("t17",1024);}

//juice level
if(S22==0){nextion_string("bt3","Empty");nextion_color("bt3",63488); }
else{nextion_string("bt3","Juice1");nextion_color("bt3",1024);}
if(S23==0){nextion_string("bt2","Empty");nextion_color("bt2",63488); }
else{nextion_string("bt2","Juice2");nextion_color("bt2",1024);}
if(S24==0){nextion_string("bt1","Empty");nextion_color("bt1",63488); }
else{nextion_string("bt1","Juice3");nextion_color("bt1",1024);}
if(S25==0){nextion_string("bt0","Empty");nextion_color("bt0",63488); }
else{nextion_string("bt0","Juice4");nextion_color("bt0",1024);}
//if(S32==0){nextion_string("t16","Empty");nextion_color("t16",63488); }
//else{nextion_string("t16","Sproute4");nextion_color("t16",1024);}

}
void bowlstorage()
{
	if(S41==0)
		{
		HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4,0);    
		HAL_GPIO_WritePin(GPIOA, GPIO_PIN_6,1);
		HAL_Delay(25000);
		HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4,0);    //lifting stop
		HAL_GPIO_WritePin(GPIOA, GPIO_PIN_6,0);
		}
		do{
		HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4,1);    //lifting motor ON upto sensor detects
		HAL_GPIO_WritePin(GPIOA, GPIO_PIN_6,0);
		}
	while(S18==1);
		HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4,0);    //lifting stop
		HAL_GPIO_WritePin(GPIOA, GPIO_PIN_6,0);
	//###operate cylinder hear
		HAL_GPIO_WritePin(GPIOE, GPIO_PIN_6,1);     //bowl pick
		HAL_Delay(1500);
		HAL_GPIO_WritePin(GPIOE, GPIO_PIN_6,0);     //bowl pick
		HAL_GPIO_WritePin(GPIOF, GPIO_PIN_2,1);      //bowl sucker on
		HAL_Delay(1500);
	
	  HAL_GPIO_WritePin(GPIOE, GPIO_PIN_3,1);      //bowl travel cylinder on
	  HAL_Delay(2500);
		HAL_GPIO_WritePin(GPIOE, GPIO_PIN_6,1);     //bowl pick
		HAL_Delay(1500);
		HAL_GPIO_WritePin(GPIOF, GPIO_PIN_2,0);      //bowl sucker off
		
		HAL_GPIO_WritePin(GPIOE, GPIO_PIN_6,0); 
		HAL_Delay(1500);
	  HAL_GPIO_WritePin(GPIOE, GPIO_PIN_3,0);       //bowl drop off
}
		

void order()
	{
		if(!(Rxdata[2]==0x00)){
   		 int a1,a2,a3,a4,a5,a6=0;
		   bowlstorage();
		   HAL_Delay(3000);
		   HAL_GPIO_WritePin(GPIOF, GPIO_PIN_10,0);    //direction conveyor motor
		   HAL_GPIO_WritePin(GPIOF, GPIO_PIN_9,1);  //brk  conveyor motor
	     user_pwm_setvalue(200);
		/*#### sprout 1 ####*/
 if(!(Rxdata[4]==0x00)){
			 HAL_GPIO_WritePin(GPIOF, GPIO_PIN_9,1);
while(S13==1);
			sp1();	
	    HAL_Delay(3000);
}
a1=1;
	if(a1==1){
     
if(!(Rxdata[5]==0x00)){
			HAL_GPIO_WritePin(GPIOF, GPIO_PIN_9,0);
while(S14==1);
	    HAL_GPIO_WritePin(GPIOF, GPIO_PIN_9,1);
		  sp2();	
		  HAL_Delay(3000);
	
		}
a2=1;
	}
if(a2==1)
		{
		 
if(!(Rxdata[6]==0x00)){
		 HAL_GPIO_WritePin(GPIOF, GPIO_PIN_9,0);
while(S15==1);
	   HAL_GPIO_WritePin(GPIOF, GPIO_PIN_9,1);
		 sp3();	
		 HAL_Delay(3000);
	
		}
a3=1;
	}
		if(a3==1)
		{
     
if(!(Rxdata[7]==0x00)){
			HAL_GPIO_WritePin(GPIOF, GPIO_PIN_9,0);
while(S16==1);
	   HAL_GPIO_WritePin(GPIOF, GPIO_PIN_9,1);
		 sp4();	
		 HAL_Delay(3000);
		}
a4=1;
	}
		
	if(a4==1)
	{
     
if(!(Rxdata[8]==0x00)){
		 HAL_GPIO_WritePin(GPIOF, GPIO_PIN_9,0);
while(S17==1);
	   HAL_GPIO_WritePin(GPIOF, GPIO_PIN_9,1);
		 sp5();	
	   HAL_Delay(3000);
	}
a5=1;
}
	
if(a5==1)
{
     
if(!(Rxdata[9]==0x00)){
	   HAL_GPIO_WritePin(GPIOF, GPIO_PIN_9,0);
while(S19==1);
	   HAL_GPIO_WritePin(GPIOF, GPIO_PIN_9,1);
		 sp6();	
	   HAL_Delay(3000);
		}
	}
     //HAL_GPIO_WritePin(GPIOF, GPIO_PIN_9,0);
	if(!(Rxdata[10]==0x00)){                      //honey  section
	   HAL_GPIO_WritePin(GPIOF, GPIO_PIN_9,0);
while(S34==1);
	   HAL_GPIO_WritePin(GPIOF, GPIO_PIN_9,1);
		 honey();
		//if(!(Rxdata[11]==0x00)) curd();           //curd section
	   HAL_Delay(1000);
	}
	if(!(Rxdata[11]==0x00)){                      //honey  section
	   HAL_GPIO_WritePin(GPIOF, GPIO_PIN_9,0);
while(S34==1);
	   HAL_GPIO_WritePin(GPIOF, GPIO_PIN_9,1);
		 curd();
		//if(!(Rxdata[11]==0x00)) curd();           //curd section
	   HAL_Delay(1000);
	}
	 HAL_GPIO_WritePin(GPIOF, GPIO_PIN_9,0);
	//lemon selection
	if(!(Rxdata[12]==0x00)){                       //lemon section
	   HAL_GPIO_WritePin(GPIOF, GPIO_PIN_9,0);
while(S21==1);
	   HAL_GPIO_WritePin(GPIOF, GPIO_PIN_9,1);
		 lemon_cut();	
	   HAL_Delay(1000);
	}
	
		HAL_GPIO_WritePin(GPIOF, GPIO_PIN_9,0);
while(S21==1);
	   
		 HAL_GPIO_WritePin(GPIOF, GPIO_PIN_9,1);
	HAL_Delay(1);
	HAL_GPIO_WritePin(GPIOF, GPIO_PIN_9,0);
	HAL_Delay(2500);
	HAL_GPIO_WritePin(GPIOF, GPIO_PIN_9,1);
		 nextion_string("g0","Please collect your order");
		 
		 HAL_Delay(1000);
		//nextion_color("b0",1024);     //button color green
  	//n extion_no("n1",1);		 //send number to hmi
	}
}
void sp1()
{
	if(Rxdata[4]==0x19)	                           //25gm        Sprout 1
			{
				HAL_GPIO_WritePin(GPIOD, GPIO_PIN_7,1);        //
			  HAL_Delay(500);
			  HAL_GPIO_WritePin(GPIOD, GPIO_PIN_7,0); 
			}
	 else if(Rxdata[4]==0x32)                          //50gm
				{
			
				HAL_GPIO_WritePin(GPIOD, GPIO_PIN_7,1);        //
			  HAL_Delay(1000);
			  HAL_GPIO_WritePin(GPIOD, GPIO_PIN_7,0); 
			}
	 else if(Rxdata[4]==0x4B)                              //75gm
				{
			
				HAL_GPIO_WritePin(GPIOD, GPIO_PIN_7,1);        //
			  HAL_Delay(2000);
			  HAL_GPIO_WritePin(GPIOD, GPIO_PIN_7,0);  
			}
   else if(Rxdata[4]==0x64)                             //100gm
				{
				
			  HAL_GPIO_WritePin(GPIOD, GPIO_PIN_7,1);        //
			  HAL_Delay(3000);
			  HAL_GPIO_WritePin(GPIOD, GPIO_PIN_7,0); 
			}	
	 else if(Rxdata[4]==0x00)HAL_GPIO_WritePin(GPIOD, GPIO_PIN_7,0); 
		}	
		
		
		
void sp2()
	{		
	if(Rxdata[5]==0x19)	                           //25gm  sprout 2
			{
				HAL_GPIO_WritePin(GPIOB, GPIO_PIN_4,1); 
				HAL_Delay(500);
				HAL_GPIO_WritePin(GPIOB, GPIO_PIN_4,0); 
			}
	 else if(Rxdata[5]==0x32)                          //50gm
				{
			
			HAL_GPIO_WritePin(GPIOB, GPIO_PIN_4,1); 
				HAL_Delay(1000);
				HAL_GPIO_WritePin(GPIOB, GPIO_PIN_4,0); 
			}
	 else if(Rxdata[5]==0x4B)                              //75gm
				{
			
				HAL_GPIO_WritePin(GPIOB, GPIO_PIN_4,1); 
				HAL_Delay(2000);
				HAL_GPIO_WritePin(GPIOB, GPIO_PIN_4,0); 
			}
   else if(Rxdata[5]==0x64)                             //100gm
				{
				
				HAL_GPIO_WritePin(GPIOB, GPIO_PIN_4,1); 
				HAL_Delay(3000);
				HAL_GPIO_WritePin(GPIOB, GPIO_PIN_4,0); 
			}	
	 else if(Rxdata[5]==0x00)HAL_GPIO_WritePin(GPIOB, GPIO_PIN_4,0);
		}	


void sp3()
		{
		if(Rxdata[6]==0x19)	                           //25gm  sprout 3
			{
				HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6,1); 
				HAL_Delay(500);
				HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6,0); 
			}
  	else if(Rxdata[6]==0x32)                          //50gm
				{		
				HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6,1); 
				HAL_Delay(1000);
				HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6,0); 
			}
	 else if(Rxdata[6]==0x4B)                              //75gm
				{
				HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6,1); 
				HAL_Delay(2000);
				HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6,0); 
			}
   else if(Rxdata[6]==0x64)                             //100gm
				{				
				HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6,1); 
				HAL_Delay(3000);
				HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6,0); 
			}	
	 else if(Rxdata[6]==0x00)HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6,0); 
		
		}
		
void sp4()
{
		if(Rxdata[7]==0x19)	                           //25gm  sprout 4
			{
				HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8,1); 
				HAL_Delay(500);
				HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8,0); 
			}
	 else if(Rxdata[7]==0x32)                          //50gm
				{		
				HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8,1); 
				HAL_Delay(1000);
				HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8,0); 
			}
	 else if(Rxdata[7]==0x4B)                              //75gm
				{
	    	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8,1); 
				HAL_Delay(2000);
				HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8,0); 
			}
   else if(Rxdata[7]==0x64)                             //100gm
				{				
	  		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8,1); 
				HAL_Delay(3000);
				HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8,0); 
			}	
	 else if(Rxdata[7]==0x00)HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8,0); 
		}

void sp5()
{	
	if(Rxdata[8]==0x19)	                           //25gm  sprout 5
			{
				HAL_GPIO_WritePin(GPIOD, GPIO_PIN_5,1); 
				HAL_Delay(500);
				HAL_GPIO_WritePin(GPIOD, GPIO_PIN_5,0); 
			}
	else if(Rxdata[8]==0x32)                          //50gm
				{		
			  HAL_GPIO_WritePin(GPIOD, GPIO_PIN_5,1); 
				HAL_Delay(1000);
				HAL_GPIO_WritePin(GPIOD, GPIO_PIN_5,0); 
			}
	 else if(Rxdata[8]==0x4B)                              //75gm
				{
        HAL_GPIO_WritePin(GPIOD, GPIO_PIN_5,1); 
				HAL_Delay(2000);
				HAL_GPIO_WritePin(GPIOD, GPIO_PIN_5,0); 
			}
   else if(Rxdata[8]==0x64)                             //100gm
				{				
			  HAL_GPIO_WritePin(GPIOD, GPIO_PIN_5,1); 
				HAL_Delay(3000);
				HAL_GPIO_WritePin(GPIOD, GPIO_PIN_5,0); 
			}	
	 else if(Rxdata[8]==0x00)HAL_GPIO_WritePin(GPIOD, GPIO_PIN_5,0); 
		}

void sp6()
{	
			if(Rxdata[9]==0x19)	                           //25gm  sprout 6
			{
				HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13,1); 
				HAL_Delay(500);
				HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13,0); 
			}
	 else if(Rxdata[9]==0x32)                          //50gm
				{		
			HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13,1); 
				HAL_Delay(1000);
				HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13,0); 
			}
	 else if(Rxdata[9]==0x4B)                              //75gm
				{
				HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13,1); 
				HAL_Delay(2000);
				HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13,0); 
			}
   else if(Rxdata[9]==0x64)                             //100gm
				{				
				HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13,1); 
				HAL_Delay(3000);
				HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13,0); 
			}	
	 else if(Rxdata[9]==0x00)HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13,0);                            
		}		
		
		/*#####   Honey  #####*/
void honey()
		{
	if(Rxdata[10]==0x01)                             
				{				
				HAL_GPIO_WritePin(GPIOA, GPIO_PIN_7,1); 
				HAL_Delay(3000);
				HAL_GPIO_WritePin(GPIOA, GPIO_PIN_7,0); 
			 }	
	else HAL_GPIO_WritePin(GPIOA, GPIO_PIN_7,0); 
}	 
			/*#####   Curd  #####*/
void curd()
{	
	if(Rxdata[11]==0x01)                             
				{				
		 
			 HAL_GPIO_WritePin(GPIOE, GPIO_PIN_7,1); 
				HAL_Delay(3000);
				HAL_GPIO_WritePin(GPIOE, GPIO_PIN_7,0); 
			 }	
	else 	HAL_GPIO_WritePin(GPIOE, GPIO_PIN_7,0); 
} 
	/*#####   Lemon  #####*/
void lemon_cut()
{
	Flash_Read_Data(0x0800FFE0, Rx_Data);        // read count value from flash  adress 0x0800FFE0
	count=Rx_Data[0];
	//Convert_To_Str((uint32_t*)Rx_Data,strc);
if(Rx_Data[0]!=0)                                   //check lemon count if 
{
	
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5,1);         // rotate 90 degree using DC motor
	while(S32==1);
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5,0); 
	count++;
	if(count>2) count=0;
  Flash_Write_Data(0x0800FFE0, &count);        // write count value to flash  adress 0x0800FFE0
	Flash_Read_Data(0x0800FFE0, Rx_Data); 
  //Convert_To_Str((uint32_t*)Rx_Data,strc);
}
else
{
	HAL_GPIO_WritePin(GPIOF, GPIO_PIN_4,1);      // Motor for drop lemon
while(S43==1);
	HAL_GPIO_WritePin(GPIOF, GPIO_PIN_4,0);      // stop 
	HAL_Delay(2000);
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5,1);      // start piston using cylinder
	HAL_Delay(2000);
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5,0);  
	HAL_Delay(1500);
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5,1);      // rotate 90 degree using DC motor
while(S32==1);
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5,0); 
	count=1;
  Flash_Write_Data(0x0800FFE0, &count);       // write count value to flash  address 0x0800FFE0
	Flash_Read_Data(0x0800FFE0, Rx_Data); 
//Convert_To_Str((uint32_t*)Rx_Data,strc);
}
}
		 /*#####   Juice 1  to 4 ##### */	 
void juice()
{	
	HAL_Delay(1000);
	if(Rxdata[13]==01)                             
				{				
				HAL_GPIO_WritePin(GPIOE, GPIO_PIN_8,1); 
				HAL_Delay(8000);
				HAL_GPIO_WritePin(GPIOE, GPIO_PIN_8,0); 
			 }	
	  else if(Rxdata[14]==01)                             
				{				
				HAL_GPIO_WritePin(GPIOB, GPIO_PIN_2,1); 
				HAL_Delay(8000);
				HAL_GPIO_WritePin(GPIOB, GPIO_PIN_2,0); 
			 }	
		else if(Rxdata[15]==01)                             
				{				
				HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0,1); 
				HAL_Delay(8000);
				HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0,0); 
			 }	
		else if(Rxdata[16]==01)                             
				{				
				HAL_GPIO_WritePin(GPIOC, GPIO_PIN_4,1); 
				HAL_Delay(8000);
				HAL_GPIO_WritePin(GPIOC, GPIO_PIN_4,0); 
			 }	
		else 
			{
		  	HAL_GPIO_WritePin(GPIOE, GPIO_PIN_8,0); 
			  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_2,0);
			  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0,0); 
				HAL_GPIO_WritePin(GPIOC, GPIO_PIN_4,0); 
				HAL_Delay(1000);
			}
}
void glass()
{
if(S39==0&&S40==0)                                       //glass check   S39 is low output sensor and other are high
	{
		do{
				HAL_GPIO_WritePin(GPIOB, GPIO_PIN_7,1);    //PB7 glass drop cylinder
				HAL_Delay(1000);
	      HAL_GPIO_WritePin(GPIOB, GPIO_PIN_7,0);    //PB7 glass drop cylinder
				HAL_Delay(2500);
		}
	while(S38==1);                                   //glass drop
				
	      HAL_GPIO_WritePin(GPIOB, GPIO_PIN_9,1);    //PB9 glass carry cylinder
				HAL_Delay(2000);
		if(S39==1)
	  	  juice();
				HAL_Delay(100);
	while(S39!=0);   
				HAL_Delay(2000);
				HAL_GPIO_WritePin(GPIOB, GPIO_PIN_9,0);  
	}
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */

  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{ 
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     tex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
