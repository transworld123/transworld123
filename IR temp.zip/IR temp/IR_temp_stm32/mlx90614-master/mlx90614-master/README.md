# mlx90614
C Library for STM32 using HAL libs to manage a Melexis MLX90614 sensor
